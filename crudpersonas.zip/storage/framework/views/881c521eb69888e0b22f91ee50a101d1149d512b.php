<?php $__env->startSection('title'); ?>
    <h2 class="text-center">DASH Personas</h2>
    <?php if(session('status')): ?>
      <div class="alert alert-success">
        <?php echo e(session('status')); ?>

      </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">  
  <div class="row">    
    <ui-view></ui-view>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
  var _personas = <?=$_personas ?>;
  var _municipios = <?=$_municipios?>;
  var _users_id = "<?php echo e($_users_id); ?>";
  var _emails = <?=$_emails; ?>
</script>
	<script src="<?php echo e(asset('app/module_app.js')); ?>"></script> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.crud', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>