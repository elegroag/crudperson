<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
      <title>CRUD Personas</title>
      <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
      <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
      <link href="<?php echo e(asset('js/angular-assets/angular-ui-notification.min.css')); ?>" rel="stylesheet" type="text/css">
      <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
      <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
      <script src="<?php echo e(asset('js/angular/angular.min.js')); ?>"></script>
      <script src="<?php echo e(asset('js/angular-assets/angular-ui-router.min.js')); ?>"></script>
      <script src="<?php echo e(asset('js/angular-assets/angular-resource.min.js')); ?>"></script>
      <script src="<?php echo e(asset('js/angular-assets/angular-ui-notification.min.js')); ?>"></script>
      <script src="<?php echo e(asset('js/angular-assets/angular-messages.min.js')); ?>"></script>
      <script src="<?php echo e(asset('js/angular-assets/angular-mocks.js')); ?>"></script>
      <script src="<?php echo e(asset('js/angular-assets/angular-animate.min.js')); ?>"></script>      
      <script src="<?php echo e(asset('js/underscore.min.js')); ?>"></script>
      <?php echo $__env->yieldContent('templates'); ?>
    </head>
    <body ng-app='app_crud'>
    	<div class="workshop">
				<div class="page-header">
					<div class="title">
						<?php echo $__env->yieldContent('title'); ?>
					</div>
				</div>
				<div class="container">
					<?php echo $__env->yieldContent('content'); ?>
				</div>
    	</div>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>